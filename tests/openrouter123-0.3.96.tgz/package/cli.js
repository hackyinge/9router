#!/usr/bin/env node

const { spawn } = require("node:child_process");
const net = require("node:net");

const DEFAULT_PORT = "5020";
const DEFAULT_HOST = "127.0.0.1";

function getPreferredPort(env = process.env) {
  const raw = env?.PORT;
  if (raw === undefined || raw === null || String(raw).trim() === "") {
    return DEFAULT_PORT;
  }
  return String(raw);
}

function getPortConflictMessage(port) {
  return [
    `Port ${port} is already in use by an existing 9router instance.`,
    `Use PORT=<new-port> openrouter123 to run on a different port.`,
  ].join("\n");
}

function formatChooserBanner(serverUrl) {
  return [
    "========================================",
    "  Choose Interface (openrouter123)",
    `  Server: ${serverUrl}`,
    "========================================",
  ].join("\n");
}

function getChooserOptions() {
  return ["Web UI", "Terminal UI", "Hide to Tray", "Exit"];
}

function checkPortAvailable(port, host) {
  return new Promise((resolve) => {
    const server = net.createServer();

    server.once("error", (err) => {
      if (err && err.code === "EADDRINUSE") {
        resolve(false);
        return;
      }
      resolve(true);
    });

    server.once("listening", () => {
      server.close(() => resolve(true));
    });

    server.listen(Number(port), host);
  });
}

function printChooser(serverUrl) {
  console.log(formatChooserBanner(serverUrl));
  getChooserOptions().forEach((option, index) => {
    const marker = index === 0 ? "★" : "☆";
    console.log(` ${marker} ${option}`);
  });
}

async function runCli() {
  const projectRoot = __dirname;
  const npmCmd = process.platform === "win32" ? "npm.cmd" : "npm";
  const port = getPreferredPort(process.env);
  const host = process.env.HOSTNAME || DEFAULT_HOST;
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || `http://localhost:${port}`;

  const available = await checkPortAvailable(port, host);
  if (!available) {
    console.error(getPortConflictMessage(port));
    process.exit(1);
    return;
  }

  printChooser(baseUrl);

  const spawnOptions = {
    cwd: projectRoot,
    stdio: process.env.ORX_CHOOSER_ACTION === "hide" ? "ignore" : "inherit",
    detached: process.env.ORX_CHOOSER_ACTION === "hide",
    env: {
      ...process.env,
      PORT: port,
      HOSTNAME: host,
      NEXT_PUBLIC_BASE_URL: baseUrl,
    },
  };

  const child = spawn(npmCmd, ["run", "dev"], spawnOptions);

  if (process.env.ORX_CHOOSER_ACTION === "hide") {
    child.unref();
    console.log(`openrouter123 is running in background on ${baseUrl}`);
    process.exit(0);
    return;
  }

  child.on("exit", (code, signal) => {
    if (signal) {
      process.kill(process.pid, signal);
      return;
    }
    process.exit(code ?? 0);
  });
}

if (require.main === module) {
  runCli();
}

module.exports = {
  getPreferredPort,
  getPortConflictMessage,
  formatChooserBanner,
  getChooserOptions,
};
