1:"$Sreact.fragment"
2:I[64795,["4335","static/chunks/c6123951-462cab681f34bf85.js","6795","static/chunks/6795-3ddcc1d55c65c001.js","505","static/chunks/505-3ffce20748d2fc09.js","4156","static/chunks/4156-ac69d9fed0825642.js","8035","static/chunks/8035-428a74e5524d6927.js","6337","static/chunks/app/(dashboard)/dashboard/page-87aa0d715eec8054.js"],"default"]
3:I[31872,[],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{"machineId":"6581be4f05a82b6b"}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"Ihds3DOj3yt0tC1dSf2Hc"}
5:null
