1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[91494,["4335","static/chunks/c6123951-462cab681f34bf85.js","6795","static/chunks/6795-3ddcc1d55c65c001.js","505","static/chunks/505-3ffce20748d2fc09.js","4156","static/chunks/4156-ac69d9fed0825642.js","3826","static/chunks/app/(dashboard)/dashboard/quota/page-394a2f89caf8c08f.js"],"CardSkeleton"]
4:I[59295,["4335","static/chunks/c6123951-462cab681f34bf85.js","6795","static/chunks/6795-3ddcc1d55c65c001.js","505","static/chunks/505-3ffce20748d2fc09.js","4156","static/chunks/4156-ac69d9fed0825642.js","3826","static/chunks/app/(dashboard)/dashboard/quota/page-394a2f89caf8c08f.js"],"default"]
5:I[31872,[],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":["$","$L3",null,{}],"children":["$","$L4",null,{}]}],null,["$","$L5",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"Ihds3DOj3yt0tC1dSf2Hc"}
6:null
