1:"$Sreact.fragment"
3:I[31872,[],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"Ihds3DOj3yt0tC1dSf2Hc"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/dashboard;307;"}
