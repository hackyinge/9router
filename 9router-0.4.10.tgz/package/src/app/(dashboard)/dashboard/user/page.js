"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Card, Badge } from "@/shared/components";
import OverviewCards from "../usage/components/OverviewCards";

const fmt = (n) => new Intl.NumberFormat().format(n || 0);

export default function SubUserPage() {
  const [user, setUser] = useState(null);
  const [keys, setKeys] = useState([]);
  const [stats, setStats] = useState({ totalRequests: 0, totalPromptTokens: 0, totalCompletionTokens: 0, totalCost: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/auth/me").then(r => r.json()),
      fetch("/api/keys").then(r => r.json()),
      fetch("/api/usage/stats?period=7d").then(r => r.json()).catch(() => ({ totalRequests: 0, totalPromptTokens: 0, totalCompletionTokens: 0, totalCost: 0 })),
    ]).then(([userData, keysData, statsData]) => {
      if (userData.role !== "sub_user") {
        window.location.href = userData.role === "super_admin" ? "/dashboard" : "/login";
        return;
      }
      setUser(userData);
      setKeys(keysData.keys || []);
      setStats(statsData);
    }).catch(() => {
      window.location.href = "/login";
    }).finally(() => {
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-text-muted">Loading...</p>
      </div>
    );
  }

  const assignedKeys = keys.filter(k => k.userId === user?.userId);

  return (
    <div className="flex flex-col gap-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold">
          {user?.displayName || user?.username || "Welcome"}
        </h1>
        <p className="text-sm text-text-muted mt-1">
          Sub-user account &middot; @{user?.username}
        </p>
      </div>

      <div>
        <h2 className="text-sm font-semibold uppercase text-text-muted mb-3">Usage (Last 7 Days)</h2>
        <OverviewCards stats={stats} />
      </div>

      <div>
        <h2 className="text-sm font-semibold uppercase text-text-muted mb-3">My API Keys</h2>
        {assignedKeys.length === 0 ? (
          <Card className="p-6 text-center">
            <p className="text-text-muted text-sm">No API keys assigned yet.</p>
            <p className="text-text-muted text-xs mt-1">Contact your administrator to get a key assigned.</p>
          </Card>
        ) : (
          <div className="flex flex-col gap-3">
            {assignedKeys.map(key => (
              <Card key={key.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-surface-alt flex items-center justify-center">
                    <span className="material-symbols-outlined text-text-muted text-[18px]">key</span>
                  </div>
                  <div>
                    <p className="font-semibold text-sm">{key.name}</p>
                    <p className="font-mono text-xs text-text-muted">
                      {key.key.slice(0, 8)}.......{key.key.slice(-4)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {key.isActive === false && <Badge variant="error" size="sm">Inactive</Badge>}
                  {key.assignedAt && (
                    <span className="text-xs text-text-muted">
                      Assigned {new Date(key.assignedAt).toLocaleDateString()}
                    </span>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <div>
        <h2 className="text-sm font-semibold uppercase text-text-muted mb-3">Quick Access</h2>
        <div className="grid grid-cols-2 gap-3">
          <QuickLink href="/dashboard/usage" icon="analytics" label="Usage &amp; Logs" desc="View your request history" />
          <QuickLink href="/dashboard/translator" icon="translate" label="Translator" desc="View request logs" />
        </div>
      </div>
    </div>
  );
}

function QuickLink({ href, icon, label, desc }) {
  return (
    <Link href={href}>
      <Card className="p-4 flex items-center gap-3 hover:border-primary transition-colors cursor-pointer">
        <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
          <span className="material-symbols-outlined text-primary text-[18px]">{icon}</span>
        </div>
        <div>
          <p className="font-semibold text-sm">{label}</p>
          <p className="text-xs text-text-muted">{desc}</p>
        </div>
      </Card>
    </Link>
  );
}