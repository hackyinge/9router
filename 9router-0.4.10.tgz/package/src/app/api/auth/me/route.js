import { NextResponse } from "next/server";
import { jwtVerify } from "jose";

const SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "9router-default-secret-change-me"
);

// GET /api/auth/me — return current user info from JWT (no auth check, returns null if not logged in)
export async function GET(request) {
  try {
    const token = request.cookies.get("auth_token")?.value;
    if (!token) return NextResponse.json({ role: null, userId: null });

    const { payload } = await jwtVerify(token, SECRET);
    return NextResponse.json({
      role: payload.role || null,
      userId: payload.userId || null,
      username: payload.username || null,
      displayName: payload.displayName || null,
      permissions: payload.permissions || [],
    });
  } catch {
    return NextResponse.json({ role: null, userId: null });
  }
}
